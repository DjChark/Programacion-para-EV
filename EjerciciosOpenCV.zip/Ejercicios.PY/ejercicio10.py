# ejercicio10_corregido.py
# pip install opencv-contrib-python numpy PyQt6
#
# FIX: el original nunca generaba marcadores ArUco para imprimir,
# así que no tenías nada que mostrarle a la cámara. Ahora los genera solo.

import sys
import cv2
import cv2.aruco as aruco
import numpy as np
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QGroupBox,
                             QListWidget, QSlider, QCheckBox, QFileDialog)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QImage, QPixmap


def crear_marco_neon():
    img = np.zeros((400, 400, 4), dtype=np.uint8)
    for i, color in enumerate([(0,255,255,255),(255,0,255,255),(255,255,0,255)]):
        offset = i*5
        cv2.rectangle(img,(50+offset,50+offset),(350-offset,350-offset),color,2)
    return img

def crear_marco_flores():
    img = np.zeros((400,400,4), dtype=np.uint8)
    for x,y,c in [(50,50,(255,192,203,200)),(350,50,(255,255,0,200)),
                  (350,350,(173,216,230,200)),(50,350,(255,182,193,200))]:
        cv2.circle(img,(x,y),40,c,-1)
    cv2.rectangle(img,(20,20),(380,380),(255,255,255,200),3)
    return img

def crear_marco_geometrico():
    img = np.zeros((400,400,4), dtype=np.uint8)
    for i in range(0,400,40):
        for j in range(0,400,40):
            pts = np.array([[i,j],[i+40,j],[i+20,j+20]],np.int32).reshape((-1,1,2))
            color = (0,255,0,100) if (i+j)%80==0 else (255,0,0,100)
            cv2.fillPoly(img,[pts],color)
    cv2.rectangle(img,(10,10),(390,390),(255,255,255,255),5)
    return img


class MarcoFotoAR(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🖼️ Marco de Foto AR – Capítulo 10 (corregido)")
        self.setGeometry(100,100,1400,800)
        self.diccionario = aruco.getPredefinedDictionary(aruco.DICT_6X6_250)
        self.detector = aruco.ArucoDetector(self.diccionario, aruco.DetectorParameters())

        # FIX: generar marcadores imprimibles automáticamente
        for i in range(4):
            m = np.zeros((300,300), dtype=np.uint8)
            aruco.generateImageMarker(self.diccionario, i, 300, m, 1)
            cv2.imwrite(f"marcador_{i}.png", m)
        print("✅ Marcadores generados: marcador_0.png a marcador_3.png")
        print("   Imprímelos o ábrelos en tu celular y muéstralos a la cámara.")

        self.catalogo = {"Marco Neón":crear_marco_neon(),"Marco Flores":crear_marco_flores(),
                          "Marco Geométrico":crear_marco_geometrico()}
        self.imagen_actual = None; self.escala = 1.0; self.borde = True
        self.cap = cv2.VideoCapture(0)
        self.timer = QTimer(); self.timer.timeout.connect(self.actualizar); self.timer.start(30)
        self.setup_ui()

    def setup_ui(self):
        central = QWidget(); self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        self.lbl_video = QLabel()
        self.lbl_video.setMinimumSize(800,600)
        self.lbl_video.setStyleSheet("background:#111; border:2px solid #555;")
        self.lbl_video.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.lbl_video, 3)

        pc = QWidget(); pc.setMaximumWidth(350); lc = QVBoxLayout(pc)

        g0 = QGroupBox("💡 Cómo usar"); v0 = QVBoxLayout()
        v0.addWidget(QLabel(
            "Se generaron 4 marcadores en esta\n"
            "misma carpeta: marcador_0.png a\n"
            "marcador_3.png\n\n"
            "Ábrelos en tu celular o imprímelos\n"
            "y muéstralos a la cámara."
        ))
        g0.setLayout(v0); lc.addWidget(g0)

        g1 = QGroupBox("🖼️ Catálogo de Marcos"); v1 = QVBoxLayout()
        self.lista = QListWidget()
        for nombre in self.catalogo: self.lista.addItem(nombre)
        self.lista.currentTextChanged.connect(self.seleccionar_marco)
        v1.addWidget(self.lista)
        btn_c = QPushButton("📂 Cargar PNG propio"); btn_c.clicked.connect(self.cargar_propio); v1.addWidget(btn_c)
        g1.setLayout(v1); lc.addWidget(g1)

        g2 = QGroupBox("⚙️ Ajustes"); v2 = QVBoxLayout()
        v2.addWidget(QLabel("Escala:"))
        sl_e = QSlider(Qt.Orientation.Horizontal); sl_e.setRange(50,200); sl_e.setValue(100)
        sl_e.valueChanged.connect(lambda v: setattr(self,'escala',v/100)); v2.addWidget(sl_e)
        cb = QCheckBox("Borde decorativo"); cb.setChecked(True)
        cb.stateChanged.connect(lambda v: setattr(self,'borde',bool(v))); v2.addWidget(cb)
        g2.setLayout(v2); lc.addWidget(g2)

        self.lbl_estado = QLabel("⏳ Buscando marcador...")
        self.lbl_estado.setStyleSheet("color:#aaa; padding:6px;")
        lc.addWidget(self.lbl_estado)
        lc.addStretch(); layout.addWidget(pc,1)
        self.lista.setCurrentRow(0)

    def seleccionar_marco(self, nombre):
        if nombre in self.catalogo: self.imagen_actual = self.catalogo[nombre].copy()

    def cargar_propio(self):
        f,_ = QFileDialog.getOpenFileName(self,"Seleccionar PNG","","PNG (*.png)")
        if f:
            img = cv2.imread(f, cv2.IMREAD_UNCHANGED)
            if img is not None:
                nombre = f.split('/')[-1]; self.catalogo[nombre] = img
                self.lista.addItem(nombre); self.lista.setCurrentRow(self.lista.count()-1)

    def superponer(self, frame, img, esquina):
        h_o,w_o = img.shape[:2]
        src = np.float32([[0,0],[w_o,0],[w_o,h_o],[0,h_o]])
        dst = esquina.astype(np.float32)
        M,_ = cv2.findHomography(src,dst)
        warped = cv2.warpPerspective(img,M,(frame.shape[1],frame.shape[0]))
        if img.shape[2]==4:
            alpha = warped[:,:,3:4]/255.0
            for c in range(3):
                frame[:,:,c] = (frame[:,:,c]*(1-alpha[:,:,0])+warped[:,:,c]*alpha[:,:,0]).astype(np.uint8)
        return frame

    def actualizar(self):
        ret, frame = self.cap.read()
        if not ret: return
        esq, ids, _ = self.detector.detectMarkers(frame)
        if ids is not None and self.imagen_actual is not None:
            aruco.drawDetectedMarkers(frame,esq,ids)
            self.lbl_estado.setText(f"✅ Marcador(es) detectado(s): {list(ids.flatten())}")
            img_ajustada = cv2.resize(self.imagen_actual,
                (max(int(self.imagen_actual.shape[1]*self.escala),10),
                 max(int(self.imagen_actual.shape[0]*self.escala),10)))
            frame = self.superponer(frame, img_ajustada, esq[0][0])
            if self.borde:
                pts = esq[0][0].astype(int)
                cv2.polylines(frame,[pts],True,(255,215,0),3)
        else:
            self.lbl_estado.setText("⏳ Buscando marcador... muéstrale uno a la cámara")
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB); h,w,ch = rgb.shape
        qt_img = QImage(rgb.data,w,h,ch*w,QImage.Format.Format_RGB888)
        pix = QPixmap.fromImage(qt_img).scaled(self.lbl_video.size(),
              Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
        self.lbl_video.setPixmap(pix)

    def closeEvent(self, event): self.cap.release(); event.accept()

def main():
    app = QApplication(sys.argv); v = MarcoFotoAR(); v.show(); sys.exit(app.exec())

if __name__ == "__main__": main()
