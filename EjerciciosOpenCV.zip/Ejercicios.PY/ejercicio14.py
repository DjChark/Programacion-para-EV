# ejercicio_14_libro_ar.py
# pip install opencv-contrib-python numpy PyQt6 mediapipe

import sys
import cv2
import cv2.aruco as aruco
import numpy as np
import time
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QGroupBox,
                             QComboBox, QTabWidget, QTextEdit, QMessageBox)
from PyQt6.QtCore import Qt, QTimer, QDateTime
from PyQt6.QtGui import QImage, QPixmap, QFont


def crear_contenido(id_m):
    colores = [(255,80,0),(0,180,100),(0,80,255),(200,0,200)]
    color = colores[id_m % len(colores)]
    img = np.zeros((200,350,4),dtype=np.uint8)
    img[:,:,:3] = color; img[:,:,3] = 160
    textos = [["Pagina "+str(id_m+1),"Capitulo "+str(id_m+1),"ID: "+str(id_m)],
              ["Animales 3D","Leon | Tigre | Aguila","Escanea para ver mas"],
              ["Vehiculos AR","Auto | Avion | Barco","Realidad Aumentada"],
              ["Naturaleza","Arboles | Plantas","El mundo natural"]][id_m%4]
    for i,t in enumerate(textos):
        cv2.putText(img,t,(15,50+i*50),cv2.FONT_HERSHEY_SIMPLEX,0.65,(255,255,255,255),2)
    return img


class LibroAR(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("📖 Libro AR Interactivo – Capítulo 14")
        self.setGeometry(100,100,1350,820)
        self.diccionario = aruco.getPredefinedDictionary(aruco.DICT_6X6_250)
        self.detector = aruco.ArucoDetector(self.diccionario, aruco.DetectorParameters())
        self.contenidos = {i: crear_contenido(i) for i in range(10)}
        # Generar marcadores para imprimir
        for i in range(8):
            m = np.zeros((300,300),dtype=np.uint8)
            aruco.generateImageMarker(self.diccionario,i,300,m,1)
            cv2.imwrite(f"marcador_{i}.png",m)
        print("Marcadores 0-7 generados. Imprímelos y úsalos con el libro.")
        self.cap = cv2.VideoCapture(0)
        self.timer = QTimer(); self.timer.timeout.connect(self.actualizar); self.timer.start(30)
        self.pagina = 0; self.ultimo_frame = None; self.marcadores_vistos = set()
        self.setup_ui()

    def setup_ui(self):
        central = QWidget(); self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        pv = QWidget(); lv = QVBoxLayout(pv)
        self.lbl_video = QLabel()
        self.lbl_video.setMinimumSize(880,650)
        self.lbl_video.setStyleSheet("background:#0a0a0a; border:3px solid #333;")
        self.lbl_video.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lv.addWidget(self.lbl_video)
        self.lbl_status = QLabel("📷 Muestra un marcador ArUco")
        self.lbl_status.setStyleSheet("font-size:13px; color:#aaa; padding:4px;")
        lv.addWidget(self.lbl_status); layout.addWidget(pv, 3)

        pc = QWidget(); pc.setMaximumWidth(380); lc = QVBoxLayout(pc)
        titulo = QLabel("📖 LIBRO AR")
        titulo.setFont(QFont("Arial",18,QFont.Weight.Bold))
        titulo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        titulo.setStyleSheet("color:#4CAF50; padding:10px;"); lc.addWidget(titulo)

        tabs = QTabWidget()
        tab_l = QWidget(); vl = QVBoxLayout(tab_l)
        vl.addWidget(QLabel("📄 Página actual:"))
        self.combo_pag = QComboBox()
        self.combo_pag.addItems(["Portada (ID 0-1)","Cap.1 Animales (ID 2-3)",
                                   "Cap.2 Vehículos (ID 4-5)","Cap.3 Naturaleza (ID 6-7)"])
        self.combo_pag.currentIndexChanged.connect(lambda i: setattr(self,'pagina',i))
        vl.addWidget(self.combo_pag)
        self.info_pag = QTextEdit(); self.info_pag.setReadOnly(True); self.info_pag.setMaximumHeight(100)
        self.info_pag.setText("Coloca un marcador ArUco frente a la cámara."); vl.addWidget(self.info_pag)
        nav = QHBoxLayout()
        for txt,fn in [("◀ Anterior",lambda: self.combo_pag.setCurrentIndex(max(0,self.pagina-1))),
                        ("Siguiente ▶",lambda: self.combo_pag.setCurrentIndex(min(3,self.pagina+1)))]:
            b = QPushButton(txt); b.clicked.connect(fn); nav.addWidget(b)
        vl.addLayout(nav); tabs.addTab(tab_l,"📖 Libro")

        tab_s = QWidget(); vs = QVBoxLayout(tab_s)
        self.lbl_stats = QLabel("Esperando..."); vs.addWidget(self.lbl_stats)
        tabs.addTab(tab_s,"📊 Stats")

        tab_a = QWidget(); va = QVBoxLayout(tab_a)
        ayuda = QTextEdit(); ayuda.setReadOnly(True)
        ayuda.setText("1. Los marcadores se generaron automáticamente\n"
                       "   (marcador_0.png … marcador_7.png)\n\n"
                       "2. Imprímelos o muéstralos en pantalla\n\n"
                       "3. Apunta la cámara a cada marcador\n"
                       "   para ver el contenido aumentado.")
        va.addWidget(ayuda); tabs.addTab(tab_a,"❓ Ayuda")
        lc.addWidget(tabs)

        btn_cap = QPushButton("📸 Capturar pantalla")
        btn_cap.clicked.connect(self.capturar)
        btn_cap.setStyleSheet("padding:8px; font-size:13px;"); lc.addWidget(btn_cap)
        lc.addStretch(); layout.addWidget(pc, 1)

    def superponer(self, frame, overlay, esquina):
        h_o,w_o = overlay.shape[:2]
        src = np.float32([[0,0],[w_o,0],[w_o,h_o],[0,h_o]])
        dst = esquina.astype(np.float32)
        M,_ = cv2.findHomography(src,dst)
        warped = cv2.warpPerspective(overlay,M,(frame.shape[1],frame.shape[0]))
        if overlay.shape[2]==4:
            alpha = warped[:,:,3:4]/255.0
            for c in range(3):
                frame[:,:,c] = (frame[:,:,c]*(1-alpha[:,:,0])+warped[:,:,c]*alpha[:,:,0]).astype(np.uint8)
        return frame

    def actualizar(self):
        ret, frame = self.cap.read()
        if not ret: return
        self.ultimo_frame = frame.copy()
        esq, ids, _ = self.detector.detectMarkers(frame)
        n = 0
        if ids is not None:
            aruco.drawDetectedMarkers(frame,esq,ids); n = len(ids)
            for i,mid in enumerate(ids.flatten()):
                self.marcadores_vistos.add(int(mid))
                if mid in self.contenidos:
                    self.superponer(frame,self.contenidos[mid],esq[i][0])
                cv2.putText(frame,f"ID:{mid}",tuple(esq[i][0][0].astype(int)+np.array([0,-12])),
                            cv2.FONT_HERSHEY_SIMPLEX,0.6,(255,255,0),2)
        self.lbl_stats.setText(f"Detectados: {n}\nDistintos: {len(self.marcadores_vistos)}\n"
                                f"IDs: {sorted(self.marcadores_vistos)}\nPágina: {self.pagina}")
        rgb = cv2.cvtColor(frame,cv2.COLOR_BGR2RGB); h,w,ch = rgb.shape
        qt_img = QImage(rgb.data,w,h,ch*w,QImage.Format.Format_RGB888)
        pix = QPixmap.fromImage(qt_img).scaled(self.lbl_video.size(),
              Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
        self.lbl_video.setPixmap(pix)
        self.lbl_status.setText(f"Detectados: {n} | Distintos: {len(self.marcadores_vistos)}")

    def capturar(self):
        if self.ultimo_frame is not None:
            ts = QDateTime.currentDateTime().toString("yyyyMMdd_hhmmss")
            nombre = f"libro_ar_{ts}.png"
            cv2.imwrite(nombre,self.ultimo_frame)
            QMessageBox.information(self,"Guardado",f"Capturado: {nombre}")

    def closeEvent(self, event): self.cap.release(); event.accept()

def main():
    app = QApplication(sys.argv); app.setStyle("Fusion")
    v = LibroAR(); v.show(); sys.exit(app.exec())

if __name__ == "__main__": main()