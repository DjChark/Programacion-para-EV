# ejercicio_09_tarjeta_ar.py
# pip install opencv-contrib-python numpy PyQt6

import sys
import cv2
import cv2.aruco as aruco
import numpy as np
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QGroupBox,
                             QLineEdit, QFileDialog)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QImage, QPixmap
import json


class TarjetaPresentacionAR(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("📇 Tarjeta de Presentación AR – Capítulo 9")
        self.setGeometry(100, 100, 1400, 800)
        self.diccionario = aruco.getPredefinedDictionary(aruco.DICT_6X6_250)
        self.detector = aruco.ArucoDetector(self.diccionario, aruco.DetectorParameters())
        self.info_tarjetas = {
            0: {"nombre":"Ana García","cargo":"Ingeniera AR","empresa":"TechVision",
                "email":"ana@techvision.com","telefono":"+52 123 456 789","color":(255,100,0)},
            1: {"nombre":"Carlos López","cargo":"Desarrollador Senior","empresa":"AR Solutions",
                "email":"carlos@arsolutions.com","telefono":"+52 987 654 321","color":(0,200,100)},
        }
        # Generar marcadores de prueba
        for i in range(4):
            m = np.zeros((300,300), dtype=np.uint8)
            aruco.generateImageMarker(self.diccionario, i, 300, m, 1)
            cv2.imwrite(f"marcador_{i}.png", m)
            print(f"Marcador {i} generado: marcador_{i}.png")
        self.cap = cv2.VideoCapture(0)
        self.timer = QTimer(); self.timer.timeout.connect(self.actualizar); self.timer.start(30)
        self.id_actual = 0
        self.setup_ui()

    def setup_ui(self):
        central = QWidget(); self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        self.lbl_video = QLabel()
        self.lbl_video.setMinimumSize(800,600)
        self.lbl_video.setStyleSheet("background:#111; border:2px solid #555;")
        self.lbl_video.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.lbl_video, 3)

        pe = QWidget(); pe.setMaximumWidth(400); lc = QVBoxLayout(pe)
        g1 = QGroupBox("🎯 Marcador Activo"); v1 = QVBoxLayout()
        self.lbl_id = QLabel(f"ID: {self.id_actual}")
        btn_m = QPushButton("◀ Anterior"); btn_m.clicked.connect(lambda: self.cambiar_id(-1))
        btn_p = QPushButton("Siguiente ▶"); btn_p.clicked.connect(lambda: self.cambiar_id(1))
        for w in [self.lbl_id, btn_m, btn_p]: v1.addWidget(w)
        g1.setLayout(v1); lc.addWidget(g1)

        g2 = QGroupBox("✏️ Editar Tarjeta"); v2 = QVBoxLayout()
        self.inputs = {}
        for campo in ["nombre","cargo","empresa","email","telefono"]:
            v2.addWidget(QLabel(campo.capitalize()+":"))
            inp = QLineEdit(); inp.textChanged.connect(self.guardar_cambios)
            v2.addWidget(inp); self.inputs[campo] = inp
        g2.setLayout(v2); lc.addWidget(g2)

        g3 = QGroupBox("💾 Acciones"); v3 = QVBoxLayout()
        btn_s = QPushButton("💾 Guardar JSON"); btn_s.clicked.connect(self.guardar_json); v3.addWidget(btn_s)
        btn_l = QPushButton("📂 Cargar JSON"); btn_l.clicked.connect(self.cargar_json); v3.addWidget(btn_l)
        g3.setLayout(v3); lc.addWidget(g3)

        info = QLabel("💡 Imprime los marcadores\nmarcador_0.png, marcador_1.png\ny muéstralos a la cámara")
        info.setStyleSheet("color:#aaa; padding:8px;"); lc.addWidget(info)
        lc.addStretch(); layout.addWidget(pe, 1)
        self.cargar_info_actual()

    def cambiar_id(self, delta):
        nuevo = self.id_actual + delta
        if 0 <= nuevo <= 9:
            self.id_actual = nuevo; self.lbl_id.setText(f"ID: {self.id_actual}"); self.cargar_info_actual()

    def cargar_info_actual(self):
        if self.id_actual in self.info_tarjetas:
            info = self.info_tarjetas[self.id_actual]
            for campo, inp in self.inputs.items(): inp.setText(info.get(campo,""))

    def guardar_cambios(self):
        if self.id_actual not in self.info_tarjetas:
            self.info_tarjetas[self.id_actual] = {"color":(0,255,0)}
        for campo, inp in self.inputs.items():
            self.info_tarjetas[self.id_actual][campo] = inp.text()

    def guardar_json(self):
        f,_ = QFileDialog.getSaveFileName(self,"Guardar","","JSON (*.json)")
        if f:
            data = {str(k):{**v,"color":list(v["color"])} for k,v in self.info_tarjetas.items()}
            with open(f,'w') as fp: json.dump(data, fp, indent=2)

    def cargar_json(self):
        f,_ = QFileDialog.getOpenFileName(self,"Cargar","","JSON (*.json)")
        if f:
            with open(f,'r') as fp: data = json.load(fp)
            self.info_tarjetas = {int(k):{**v,"color":tuple(v["color"])} for k,v in data.items()}
            self.cargar_info_actual()

    def dibujar_tarjeta(self, frame, info, esquinas):
        pts = esquinas[0].astype(int)
        x1,y1 = pts[:,0].min(), pts[:,1].min()
        x2,y2 = pts[:,0].max(), pts[:,1].max()
        pad = max((x2-x1)//2, 30)
        bx1=max(0,x1-pad); bx2=min(frame.shape[1],x2+pad)
        by1=max(0,y1-pad); by2=min(frame.shape[0],y2+pad*2)
        overlay = frame.copy(); color = info.get("color",(0,255,0))
        cv2.rectangle(overlay,(bx1,by1),(bx2,by2),color,-1)
        cv2.addWeighted(overlay,0.35,frame,0.65,0,frame)
        cv2.rectangle(frame,(bx1,by1),(bx2,by2),color,3)
        campos = [("nombre","📇"),("cargo","👔"),("empresa","🏢"),("email","📧"),("telefono","📞")]
        for i,(campo,icono) in enumerate(campos):
            txt = f"{icono} {info.get(campo,'')}"
            cv2.putText(frame,txt,(bx1+10,by1+30+i*28),cv2.FONT_HERSHEY_SIMPLEX,0.55,(255,255,255),2)

    def actualizar(self):
        ret, frame = self.cap.read()
        if not ret: return
        esq, ids, _ = self.detector.detectMarkers(frame)
        if ids is not None:
            aruco.drawDetectedMarkers(frame, esq, ids)
            for i, mid in enumerate(ids.flatten()):
                if mid in self.info_tarjetas:
                    self.dibujar_tarjeta(frame, self.info_tarjetas[mid], esq[i])
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB); h,w,ch = rgb.shape
        qt_img = QImage(rgb.data,w,h,ch*w,QImage.Format.Format_RGB888)
        pix = QPixmap.fromImage(qt_img).scaled(self.lbl_video.size(),
              Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
        self.lbl_video.setPixmap(pix)

    def closeEvent(self, event): self.cap.release(); event.accept()

def main():
    app = QApplication(sys.argv); v = TarjetaPresentacionAR(); v.show(); sys.exit(app.exec())

if __name__ == "__main__": main()